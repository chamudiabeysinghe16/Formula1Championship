package com.company;

import java.io.Serializable;


public class Formula1Driver extends Driver implements Serializable{
    private String clubName;
    private String Location;
    private int Wins;
    private int Draws;
    private int  Defeats;
    private int Received_goals;
    private int  Scored_goals;
    private int Points;
    private int Number_of_matches;


    public Formula1Driver(String clubName, String Location, int Wins, int Draws, int Defeats, int Received_goals, int Scored_goals, int Points, int Number_of_matches){
        super(clubName,Location);
        this.setWins(Wins);
        this.setClubName(clubName);
        this.setLocation(Location);
        this.setDraws(Draws);
        this.setDefeats(Defeats);
        this.setReceived_goals(Received_goals);
        this.setScored_goals(Scored_goals);
        this.setPoints(Points);
        this.setNumber_of_matches(Number_of_matches);

    }


    @Override
    public String toString() {
        return "Formula1Driver{" +
                "clubName='" + getClubName() + '\'' +
                ", Wins=" + getWins() +
                ", Draws=" + getDraws() +
                ", Defeats=" + getDefeats() +
                ", Received_goals=" + getReceived_goals() +
                ", Scored_goals=" + getScored_goals() +
                ", Points=" + getPoints() +
                ", Number_of_matches=" + getNumber_of_matches() +
                '}';
    }

    public String getClubName() {
        return clubName;
    }

    public void setClubName(String clubName) {
        this.clubName = clubName;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }

    public int getWins() {
        return Wins;
    }

    public void setWins(int wins) {
        Wins = wins;
    }

    public int getDraws() {
        return Draws;
    }

    public void setDraws(int draws) {
        Draws = draws;
    }

    public int getDefeats() {
        return Defeats;
    }

    public void setDefeats(int defeats) {
        Defeats = defeats;
    }

    public int getReceived_goals() {
        return Received_goals;
    }

    public void setReceived_goals(int received_goals) {
        Received_goals = received_goals;
    }

    public int getScored_goals() {
        return Scored_goals;
    }

    public void setScored_goals(int scored_goals) {
        Scored_goals = scored_goals;
    }

    public int getPoints() {
        return Points;
    }

    public void setPoints(int points) {
        Points = points;
    }

    public int getNumber_of_matches() {
        return Number_of_matches;
    }

    public void setNumber_of_matches(int number_of_matches) {
        Number_of_matches = number_of_matches;
    }
}
