/*
package com.company;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class Formula1ChampionshipManagerTest {

    @Test
    void getDriversArray() {
    }

    @Test
    void getRacesArray() {
    }

    @Test
    void addNewDriver() {
    }

    @Test
    void deleteDriver() {
    }

    @Test
    void changeDriver() {
    }

    @Test
    void showStatistics() {
    }

    @Test
    void displayFormula1DriverTable() {
    }

    @Test
    void addRaceCompleted() {
    }

    @Test
    void saveInformation() {
    }

    @Test
    void getInfo() {
    }
}*/
