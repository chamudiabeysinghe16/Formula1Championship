/*
package com.company;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RaceCompletedTest {

    @Test
    void getDriverName() {
    }

    @Test
    void setDriverName() {
    }

    @Test
    void getPosition() {
    }

    @Test
    void setPosition() {
    }

    @Test
    void getCurrentPoints() {
    }

    @Test
    void setCurrentPoints() {
    }

    @Test
    void getTeamName() {
    }

    @Test
    void setTeamName() {
    }

    @Test
    void getFirstPositionCount() {
    }

    @Test
    void setFirstPositionCount() {
    }

    @Test
    void getSecondPositionCount() {
    }

    @Test
    void setSecondPositionCount() {
    }

    @Test
    void getThirdPositionCount() {
    }

    @Test
    void setThirdPositionCount() {
    }

    @Test
    void getNumOfDrivers() {
    }

    @Test
    void setNumOfDrivers() {
    }

    @Test
    void getNoOfParticipatedRaces() {
    }

    @Test
    void setNoOfParticipatedRaces() {
    }
}*/
