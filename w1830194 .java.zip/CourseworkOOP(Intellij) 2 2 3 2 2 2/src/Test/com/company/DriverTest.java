/*
package com.company;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DriverTest {

    @Test
    void testToString() {
    }

    @Test
    void getNameOfDriver() {
    }

    @Test
    void setNameOfDriver() {
    }

    @Test
    void getLocation() {
    }

    @Test
    void setLocation() {
    }

    @Test
    void getTelNum() {
    }

    @Test
    void setTelNum() {
    }

    @Test
    void getInsuranceNum() {
    }

    @Test
    void setInsuranceNum() {
    }

    @Test
    void getCarManufacturer() {
    }

    @Test
    void setCarManufacturer() {
    }
}*/
