/*
package com.company;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class Formula1DriverTest {

    @Test
    void getPoints() {
    }

    @Test
    void setPoints() {
    }

    @Test
    void getNoOfParticipatedRaces() {
    }

    @Test
    void setNoOfParticipatedRaces() {
    }

    @Test
    void getNumOfDrivers() {
    }

    @Test
    void setNumOfDrivers() {
    }

    @Test
    void getCarNumber() {
    }

    @Test
    void setCarNumber() {
    }

    @Test
    void testToString() {
    }

    @Test
    void getFirstPositionCount() {
    }

    @Test
    void setFirstPositionCount() {
    }

    @Test
    void getSecondPositionCount() {
    }

    @Test
    void setSecondPositionCount() {
    }

    @Test
    void getThirdPositionCount() {
    }

    @Test
    void setThirdPositionCount() {
    }

    @Test
    void getPosition() {
    }

    @Test
    void setPosition() {
    }

    @Test
    void getDate() {
    }

    @Test
    void setDate() {
    }
}*/
