/*
package com.company;

import static org.junit.jupiter.api.Assertions.*;

class ChampionshipManagerTest {

    @org.junit.jupiter.api.Test
    void addNewDriver() {
    }

    @org.junit.jupiter.api.Test
    void deleteDriver() {
    }

    @org.junit.jupiter.api.Test
    void changeDriver() {
    }

    @org.junit.jupiter.api.Test
    void showStatistics() {
    }

    @org.junit.jupiter.api.Test
    void displayFormula1DriverTable() {
    }

    @org.junit.jupiter.api.Test
    void addRaceCompleted() {
    }

    @org.junit.jupiter.api.Test
    void saveInformation() {
    }
}*/
